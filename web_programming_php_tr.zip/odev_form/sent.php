<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="style.css"/>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <title>İnsan Kaynakları Formu</title>
    </head>
    <body>
        <header class="kutu">
            <h1>İnsan Kaynakları Formu</h1>
        </header>
        <main>
            <section class="kutu">
            <?php

            // veri girişlerini kontrol et ve düzenle
            $v_isim = trim($_POST["isim"]," ");
            $v_soyisim = trim($_POST["soyisim"]," ");
            $v_yas = $_POST["yas"];
            $v_dogum = $_POST["dogum"];
            $v_eposta = trim($_POST["eposta"]," ");
            $v_telno = $_POST["telno"];
            $v_egitimdurumu = $_POST["egitimdurumu"];

            if(isset($_POST["askerlikdurumu"]))
                $v_askerlikdurumu = $_POST["askerlikdurumu"];
            else
                $v_askerlikdurumu = "null";

            if(isset($_POST["hobi1"]))
                $v_hobi1 = $_POST["hobi1"];
            else
                $v_hobi1 = "yok";

            if(isset($_POST["hobi2"]))
                $v_hobi2 = $_POST["hobi2"];
            else
                $v_hobi2 = "yok";

            if(isset($_POST["hobi3"]))
                $v_hobi3 = $_POST["hobi3"];
            else
                $v_hobi3 = "yok";

            if(isset($_POST["hobi4"]))
                $v_hobi4 = $_POST["hobi4"];
            else
                $v_hobi4 = "yok";

            // dosya bilgilerini ve koyulacak dizini belirle
            $dizin = '/uploads/';
            $dosya_ismi = $_FILES["cvdosyasi"]["name"]; 
            $yuklenecek_dosya = __DIR__ . $dizin . $dosya_ismi;
            $dosya_tipi = strtolower(pathinfo($yuklenecek_dosya,PATHINFO_EXTENSION));

            // md5le sonra tekrar ata
            $md5lendin = md5($dosya_ismi . $v_isim);
            $dosya_ismi = $md5lendin . "." . $dosya_tipi;
            $yuklenecek_dosya = __DIR__ . $dizin . $dosya_ismi;

            
            

            if ($dosya_tipi == "pptx" || $dosya_tipi == "doc" || $dosya_tipi == "docx") {

                $sonuc = move_uploaded_file($_FILES["cvdosyasi"]["tmp_name"], $yuklenecek_dosya);
              
                echo $sonuc ? "Dosya başarıyla yüklendi" : "Hata oluştu";
              
            } else {
              
                echo "Desteklenmeyen dosya biçimi";
              
            }
            echo "<br>";
            echo '<a href="index.php">Geri dönmek için buraya dokunun</a>';
            
            echo "<br><br> Girilen bilgiler tam liste: <br>";
            echo "İsim: ". $v_isim ."<br>";
            echo "Soyisim: ". $v_soyisim ."<br>";
            echo "Yaş: ". $v_yas ."<br>";
            echo "Doğum günü: ". $v_dogum ."<br>";
            echo "E-posta adresi: ". $v_eposta ."<br>";
            echo "Telefon numarası: ". $v_telno ."<br>";
            echo "Eğitim durumu değeri: ". $v_egitimdurumu ."<br>";
            echo "Askerlik durumu değeri: ". $v_askerlikdurumu ."<br>";
            echo "Hobiler: ". $v_hobi1 . " " . $v_hobi2 . " " . $v_hobi3 . " " . $v_hobi4 . "<br>";

            $txtatmayeri = "kisiler/" . $md5lendin . ".txt";
            $txtdosya = fopen($txtatmayeri,"w");

            fwrite($txtdosya,("İsim: " . $v_isim . "\n"));
            fwrite($txtdosya,("Soyisim: " . $v_soyisim . "\n"));
            fwrite($txtdosya,("Yaşı: " . $v_yas . "\n"));
            fwrite($txtdosya,("Doğum tarihi: " . $v_dogum . "\n"));
            fwrite($txtdosya,("E-posta: " . $v_eposta . "\n"));
            fwrite($txtdosya,("Telefon numarası: " . $v_telno . "\n"));
            fwrite($txtdosya,("Eğitim durumu: " . $v_egitimdurumu . "\n"));
            fwrite($txtdosya,("Askerlik durumu: " . $v_askerlikdurumu . "\n\n"));

            fclose($txtdosya);

            echo "<br>" . "<br>" . "Hata ayıklama:" . "<br>";
            print_r($_FILES['cvdosyasi']);
            echo "<br>";
            print_r($_FILES['cvdosyasi']['name']);
            echo "<br>";
            echo $dosya_ismi;
            echo "<br>";
            print_r($_FILES['cvdosyasi']['type']);
            echo "<br>";
            print_r($_FILES['cvdosyasi']['tmp_name']);
            echo "<br>";
            print_r($_FILES['cvdosyasi']['error']);
            echo "<br>";
            echo dirname(__FILE__);
            echo "<br>";
            echo __DIR__;
            echo "<br>";
            echo $dosya_tipi;
            echo "<br>";

            ?>
            </section>
        </main>
    </body>
</html>