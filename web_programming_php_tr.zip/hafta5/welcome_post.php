<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Post Gönderildi</title>
</head>
<body>
    <h1>Başarılı!</h1>
    <?php
    echo "Your name: ".$_POST["fname"]."<br>";
    echo "Your email: ".$_POST["email"]."<br>";
    echo var_dump($_POST["fname"]);
    echo "<br>";
    echo var_dump($_POST["email"]);
    ?>

</body>
</html>