<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Çalışma 3</title>
</head>
<body>
    <?php
    class Araba {
        public $isim;
        public $renk;

        function __construct($isim,$renk)
        {
            $this->isim = $isim;
            $this->renk = $renk;
        }

        function __destruct()
        {
            echo "Yeni bir araba eklendi: {$this->isim} <br>";
        }

        function get_isim(){
            return $this->isim;
        }

        function get_renk(){
            return $this->renk;
        }

        const INTRO = "Birbirinden eşsiz ve uygun fiyatta arabalarımız var. Sakın kaçırmayın!";
        
    }

    $toyota = new Araba("Toyota Corolla Cross","Beyaz");
    $bmw = new Araba("BMW E60","Mavi");
    $togg = new Araba("TOGG T10S C-segment Sedan","Kırmızı");
    $volks = "";
    
    echo Araba::INTRO;
    echo "<br>";
    echo "<br>";
    

    echo "Arabalar ve renkleri:";
    echo "<br>";
    echo $togg->get_isim() . " / " . $togg->get_renk();
    echo "<br>";
    echo $bmw->get_isim() . " / " . $bmw->get_renk();
    echo "<br>";
    echo $toyota->get_isim() . " / " . $toyota->get_renk();
    echo "<br>";
    echo "<br>";
    
    
    ?>
</body>
</html>