<!DOCTYPE html>
<html>
    <head>
        <title>Deneme3</title>
    </head>
    <body>
        <h1>yeni dünya</h1><br>

        <?php
        echo "Bölüm0:";
        echo "<br>";
        echo(rand(5,9));
        echo "<br>";
        echo(abs(6));
        echo "<br>";
        echo(abs(-6));
        echo "<br>";
        echo "<br>";
        echo(round(6.5));
        echo "<br>";
        echo(round(-6.5));
        echo "<br>";
        echo(round(-6.4));
        echo "<br>";
        echo(round(6.556765,2));
        echo "<br>";
        echo(round(-6.545999,2));
        echo "<br>";
        echo "<br>";
        
        echo(pow(-2,3) . "<br>");
        echo(pow(-2,3.2));
        echo "<br>";
        echo "<br>";
        
        
        ?>

        <?php
        echo "Bölüm1:" . "<br>";
        $str1 = "Ben eve ekmek aldim.";
        print_r(explode(" ",$str1));
        echo "<br>";
        print_r(explode(" ",$str1, 4));
        echo "<br>";
        print_r(explode(" ",$str1, 2));
        echo "<br>";
        print_r(explode(" ",$str1, -1));
        echo "<br>";
        print_r(explode(" ",$str1, -2));
        echo "<br>";
        print_r(explode(" ",$str1, -3));
        echo "<br>";
        ?>

        <?php
        echo "<br>";
        echo "Bölüm2:" . "<br>";
        $dizi1 = array("Sen","pazardan","domates","aldin","mi?");
        echo implode(" ",$dizi1);
        echo "<br>";
        echo implode(",",$dizi1);
        echo "<br>";
        echo implode("V",$dizi1);
        echo "<br>";
        ?>

        <?php
        echo "<br>";
        echo "Bölüm3:" . "<br>";
        $dizi2 = array("Sen","pazardan","domates","almadin","mi?");
        echo join(" ",$dizi2);
        echo "<br>";
        echo join(",",$dizi2);
        echo "<br>";
        echo join("V",$dizi2);
        echo "<br>";
        ?>

        <?php
        echo "<br>";
        echo "Bölüm4:" . "<br>";
        $str2 = "merhaba dunya!";
        echo $str2;
        echo "<br>";
        echo trim($str2,"merya!");
        echo "<br>";
        echo ltrim($str2,"mer");
        echo "<br>";
        echo rtrim($str2,"ya!");
        echo "<br>";
        $str2_2 = "  \n \0 merhaba dunya!    ";
        echo "<br>";
        echo $str2_2;
        echo "<br>";
        echo trim($str2_2);
        echo "<br>";
        ?>

        <?php
        echo "<br>";
        echo "Bölüm5:" . "<br>";
        $str3 = "merhaba dunya!";
        echo $str3 . "<br>";
        echo md5($str3);
        echo "<br>";
        $str3 = "merhabadunya!";
        echo $str3 . "<br>";
        echo md5($str3);
        echo "<br>";
        $str3 = "Merhaba dunya!";
        echo $str3 . "<br>";
        echo md5($str3);
        echo "<br>";
        echo $str3 . "<br>";
        echo md5($str3,true);
        echo "<br>";
        ?>

        <?php
        echo "<br>";
        echo "Bölüm6:" . "<br>";
        $str4 = "birinci\nikinci\nucuncu";
        echo $str4;
        echo "<br>"."<br>";
        echo nl2br($str4);
        echo "<br>";
        ?>

        <?php
        echo "<br>";
        echo "Bölüm7:" . "<br>";
        echo "1000000"."<br>";
        echo number_format(1000000)."<br>";
        echo number_format("1000000")."<br>";
        echo number_format("1000000",2)."<br>";
        echo number_format("1000000",2,",",".");
        echo "<br>";
        
        ?>

        <?php
        echo "<br>";
        echo "Bölüm8:" . "<br>";
        $age=array("Peter"=>"35","Alp"=>"99");
        print "Peter " . $age['Peter'] . " yasinda.";
        echo "<br>";
        print "Alperen " . $age['Alp'] . " yaşında.";
        echo "<br>";
        
        ?>

        <?php
        echo "<br>";
        echo "Bölüm9:" . "<br>";
        $str3 = "merhaba dunya!";
        echo $str3 . "<br>";
        echo sha1($str3);
        echo "<br>";
        $str3 = "merhaba dunya";
        echo $str3 . "<br>";
        echo sha1($str3);
        echo "<br>";
        $str3 = "Merhaba dunya!";
        echo $str3 . "<br>";
        echo sha1($str3);
        echo "<br>";
        echo $str3 . "<br>";
        echo sha1($str3,true);
        echo "<br>";
        ?>

        <?php
        echo "<br>";
        echo "Bölüm10:" . "<br>";
        $str4 = "Tekrarla";
        echo str_repeat($str4,5);
        echo "<br>";
        echo str_replace("la","dalak",$str4);
        echo "<br>";
        $str4 = "Tekrarla";
        print_r(str_split($str4));
        echo "<br>";
        $str4 = "Tekrarla";
        print_r(str_split($str4,3));
        echo "<br>";
        echo "yeni dunya!"."<br>";
        echo str_word_count("yeni dunya!");
        ?>

        <?php
        echo "<br>";
        echo "<br>";
        echo "Bölüm11:" . "<br>";
        echo strip_tags("<b>Hello</b> <i>world!</i>","<b>");
        echo "<br>";
        $strr1 = "ben ekmek aldim ama yanlislikla tam bugdayli ekmek almisim";
        echo $strr1;
        echo "<br>";
        echo strpos($strr1,"ekmek");
        echo "<br>";
        echo strrpos($strr1,"ekmek");
        echo "<br>";
        ?>

        <?php
        echo "<br>";
        echo "<br>";
        echo "Bölüm12:" . "<br>";
        $strr2 = "ekmek";
        echo $strr2;
        echo "<br>";
        echo strlen($strr2);
        echo "<br>";
        $strr2 = "eğmek";
        echo $strr2;
        echo "<br>";
        echo strlen($strr2);
        echo "<br>";
        $strr3 = "EKMek"."<br>";
        echo $strr3."<br>";
        echo strtoupper($strr3);
        echo "<br>";
        echo strtolower($strr3);
        echo "<br>";
        echo substr("Hello world",0);
        echo "<br>";
        echo substr("Hello world",6);
        echo "<br>";
        echo substr("Hello world",-7);
        echo "<br>";
        echo substr("Hello world",1,10)."<br>";
        echo "<br>";
        $str = "This is nice";
        echo $str . "<br>";
        echo strlen($str)."<br>"; // Using strlen() to return the string length
        echo substr_count($str,"is")."<br>"; // The number of times "is" occurs in the string
        echo substr_count($str,"is",2)."<br>"; // The string is now reduced to "is is nice"
        echo substr_count($str,"is",3)."<br>"; // The string is now reduced to "s is nice"
        echo substr_count($str,"is",3,3)."<br>"; // The string is now reduced to "s i"
                
        ?>
        <?php
        echo "<br>";
        
        $arr = array("blue","red","red","yellow");
        print_r(str_replace("red","pink",$arr,$i));
        echo "Replacements: $i";
        ?>

        

    </body>
</html>