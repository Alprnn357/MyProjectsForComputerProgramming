<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Kaydol</title>
</head>
<body>

    <h1>Kaydolunuz</h1>

    <form method="post" enctype="multipart/form-data">
        <label for="email">E-posta: </label><input type="text" name="email"><br>
        <label for="password">Şifre: </label><input type="password" name="password"><br>
        <label for="passwordreenter">Şifreyi tekrar giriniz: </label><input type="password" name="passwordreenter"><br>
        <input type="submit" formaction="registered.php" value="Kaydol">
    </form>

</body>
</html>