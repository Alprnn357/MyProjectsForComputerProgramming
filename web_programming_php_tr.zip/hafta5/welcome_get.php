<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Get Gönderildi</title>
</head>
<body>
    <h1>Başarılı!</h1><br>
    <?php
    echo "Your name: ".$_GET["fname"]."<br>";
    echo "Your email: ".$_GET["email"];
    ?>
    
</body>
</html>