<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>VIZE3</title>
</head>
<body>
    <h1>HHERKESE MERHABA</h1>
    <p>ben php kodluyom</p><br><br>

    <?php
    
    echo "<br>";
    
    echo "Bugünün zamanı: " . date("d D l / m M F / y Y / H i s / h a A / g G");
    echo "<br>";
    echo "Bugünün zamanı: " . date("d F Y l / H:i:s");
    echo "<br>";
    


    $x = 8;
    $y = 3;
    $t = 5;

    for($z = 1; $z <= $x; $z++){
        echo "Benim sayım: " . $z . "<br>";
    }

    echo "<br>";

    do{
        echo "2. sayım: " . $t . "<br>";
        $t--;
    } while($t >= 2);

    echo "<br>";
    
    $dizi = array("alp","can","eren");

    foreach($dizi as $pro){
        echo "İsim: " . $pro . "<br>"; 
    }

    $dizi2 = array("a"=>"armut","b"=>"bronz","c"=>"coss");

    foreach($dizi2 as $a => $b){
        echo $a . " anahtarı " . $b . "<br>";
    }

    echo "<br>";
    echo "<br>";
    
    $newtext = 4;
    switch($newtext){
        case 5:
            echo "yaprağııımmmm";
            break;
        default:
            echo "pü senin suratına sıfatına tüküreyim";
            break;
    }

    echo "<br>";
    echo "<br>";
    


    ?>

</body>
</html>