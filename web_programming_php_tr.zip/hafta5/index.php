<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>title</title>
</head>
<body>
    <h1>First form</h1>
    <form action="welcome_post.php" method="post">
        <label>Name: </label><input type="text" name="fname" placeholder="giriniz..."><br>
        <label>E-mail: </label><input type="email" name="email" placeholder="giriniz..."><br>
        <label>Tel: </label><input type="tel" name="phone_number"><br>

        <label>Askerlik durumu: </label><br>
        <input type="radio" name="askerlikdurumu" value="yapti">Yaptı<br>
        <input type="radio" name="askerlikdurumu" value="tecilli">Tecilli<br>
        <input type="radio" name="askerlikdurumu" value="muaf">Muaf<br>

        <label>Hobiler: </label><br>
        <input type="checkbox" name="hobi[]" value="kitap">Kitap okuma<br>
        <input type="checkbox" name="hobi[]" value="gezi">Gezi yapma<br>
        <input type="checkbox" name="hobi[]" value="kapanma">Kapanma <br>

        <label>Hobiler: </label><br>
       
        <input type="submit" value="POST ile gönder">
    </form>
</body>
</html>