<?php
session_start();

if ( !(isset($_SESSION["email"]) && isset($_SESSION["password"])) ) {
    header('Location: index.php');
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Ana sayfa</title>
</head>
<body>
    <?php
    include 'class/vt.php';
    $sql = "SELECT logintime FROM users WHERE email = '" . $_SESSION["email"] . "' AND password = '" . $_SESSION["password"] . "'";
    $result = $baglanti->conn->query($sql);
    $row = $result->fetch_assoc();
    ?>
    <h1>Ana sayfaya hoş geldiniz</h1>
    <p>Giriş zamanı: </p><?php echo $row["logintime"] ?><br><br>
    <a href="logouted.php">çıkış yap</a>
</body>
</html>