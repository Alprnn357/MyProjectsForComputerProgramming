<?php
class VT
{

    /* public $servername;
    public $username;
    public $password;
    public $dbname; */
    public $conn;

    function __construct($servername, $username, $password, $dbname)
    {
        $this->conn = new mysqli($servername, $username, $password, $dbname);

        echo $this->conn->connect_error;
    }
}

$baglanti = new VT("localhost", "root", "", "bozok");

?>