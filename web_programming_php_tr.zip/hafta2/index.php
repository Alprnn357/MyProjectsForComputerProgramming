<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    echo date("H:i") . "<br>";
    $cur_hour = date("H");

    if (($cur_hour >= 6) && ($cur_hour < 12))
        echo "Günaydın";
    elseif (($cur_hour >= 12) && ($cur_hour < 17))
        echo "İyi Öğlenler";
    elseif (($cur_hour >= 17) && ($cur_hour < 24))
        echo "İyi Akşamlar";
    elseif (($cur_hour >= 00) && ($cur_hour < 6))
        echo "İyi Geceler";
    else
        echo "Hata";

    ?>
</body>
</html>