<!DOCTYPE html>
<?php
$c_isim = 'alprnn';
$c_deger = '1234';
//setcookie($c_isim, $c_deger, time() + (86400 * 30), "/"); // 86400 = 1 day
//setcookie($c_isim, "", ((86400 * 30)-(86400 * 30)) , "/");
?>
<html>
<head>
    <meta charset="UTF-8" />
    <title>final1</title>
</head>
<body>
    <?php
    
    if ( !(isset($_COOKIE[$c_isim])) ) {
        echo 'Cookie ayarlanmamış veya yok';
    }
    else {
        echo 'Cookie ismi: ' . $c_isim . '<br>';
        echo 'Cookie değeri: ' . $_COOKIE[$c_isim];
    }

    echo "<br>";
    echo "<br>";
    echo "<br>";
    

    // class Fruit {

    //     public $isim;
    //     public $renk;

    //     function setisim($isim){
    //         $this->isim = $isim;
    //     }

    //     function getisim(){
    //         return $this->isim;
    //     }

    // }

    // $elma = new Fruit();

    // $elma->setisim('Elma');

    // echo "merhaba ben " . $elma->getisim();


    // class Fruit {

    //     public $isim;
    //     public $renk;

    //     function __construct($isim,$renk){
    //         $this->isim = $isim;
    //         $this->renk = $renk;
    //     }

    //     function getisim(){
    //         return $this->isim;
    //     }

    //     function getrenk(){
    //         return $this->renk;
    //     }

    // }

    // $elma = new Fruit('Elmacık','sarı');


    // echo "merhaba benim " . $elma->getisim() . ' '. $elma->getrenk() . ' renginde';


    class Fruit {

        public $isim;
        public $renk;

        function __construct($isim,$renk){
            $this->isim = $isim;
            $this->renk = $renk;
        }

        function __destruct()
        {
            echo "merhaba benim " . $this->isim . ' '. $this->renk . ' renginde';
        }

    }

    $elma = new Fruit('elmam','kırmızı');

    ?>
</body>
</html>