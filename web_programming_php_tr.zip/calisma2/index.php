<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Çalışma 2</title>
</head>
<body>
    <?php
    $dosya = fopen("not.txt","w");
    $yazi = "merhaba nasılsın iyimisin";
    fwrite($dosya,$yazi);
    fclose($dosya);

    $dosya = fopen("not.txt","r");
    echo fread($dosya,filesize("not.txt"));
    fclose($dosya);
    ?>
</body>
</html>