<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
    <meta charset="UTF-8" />
    <title>???</title>
</head>
<body>
    
    <?php
    include "class/vt.php";
    
    $sqlekle = 'INSERT INTO students VALUES ('.$_POST["id"].',"'.$_POST["firstName"].'","'.$_POST["lastName"].'",'.$_POST["schoolno"].',"'.$_POST["city"].'")';
    if ($baglanti->conn->query($sqlekle) === TRUE) {
        echo '<h1>Kayıt başarıyla eklendi!</h1>';
        }
    else
    {
        echo 'The error occured. <br>'.$baglanti->conn->error;
    }

    
    $baglanti->conn->close();
    ?>
    <br><br>
    <a href="index.php">Go back to form</a>

</body>
</html>