<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Giriş sayfası</title>
</head>
<body>

    <?php
    include 'class/vt.php';

    $r_email = trim($_POST["email"]);
    $r_password = md5($_POST["password"]);

    $sqlkontrol = "SELECT * FROM users WHERE email = '" . $r_email . "' AND password = '" . $r_password . "'";
    $result = $baglanti->conn->query($sqlkontrol);
    $row = $result->fetch_assoc();

    if($r_email == $row["email"] && $r_password == $row["password"])
    {
        $sqlzaman = "UPDATE users SET logintime = CURRENT_TIMESTAMP() WHERE email = '".$r_email."';";
        $baglanti->conn->query($sqlzaman);
        $_SESSION["email"] = $r_email;
        $_SESSION["password"] = $r_password;
        echo '<h1>Giriş başarılı!</h1><br><a href="mainpage.php">Sayfaya git</a>';
    }
    else
    {
        echo '<h1>Giriş hatası!</h1><br><a href="index.php">Geri dön</a>';
    }

    // $sqlkontrol = "SELECT * FROM users WHERE email = 'eheh@hotmail.com' AND password = '81dc9bdb52d04dc20036dbd8313ed055'";
    

        // if($baglanti->conn->query($sqlkontrol) === TRUE)
        // {
    

            

        // }
        // else
        // {
        //     echo '<h1>Giriş hatası!</h1><br><a href="index.php">Geri dön</a>';
        // }


    ?>

</body>
</html>