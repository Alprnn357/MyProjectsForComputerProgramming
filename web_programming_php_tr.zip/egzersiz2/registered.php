<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Kaydolma sayfası</title>
</head>
<body>

    <?php
    include 'class/vt.php';

    $r_email = trim($_POST["email"]);
    $r_password = md5($_POST["password"]);
    $r_reenter = md5($_POST["passwordreenter"]);

    if($r_password == $r_reenter)
    {
        

        $sqlekle = "INSERT INTO users (email,password,logintime) VALUES ('" . $r_email . "','" . $r_password . "',CURRENT_TIMESTAMP())";
        if($baglanti->conn->query($sqlekle) === TRUE)
        {
            $_SESSION["email"] = $r_email;
            $_SESSION["password"] = $r_password;

            echo '<h1>Kaydolma başarılı!</h1><br><a href="mainpage.php">Sayfaya git</a>';

        }
        else
        {
            echo '<h1>Kaydolma başarılı!</h1><br><a href="register.php">Geri dön</a>';
        }
        
    }


    ?>

</body>
</html>