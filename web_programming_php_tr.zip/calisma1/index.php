<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Çalışma1</title>
</head>
<body>
    <h1>Çalışma1</h1><br>
    <p>veritabanına bağlan.</p><br>
    <?php
    $baglanti = mysqli_connect("localhost","root","","alpalpalp");

    if(!$baglanti){
        echo "bağlantı başarısız!"."<br>";
    }
    else
    {
        echo "bağlantı başarılı!"."<br>";
    }

    // $sql = "insert into kisiler (isim,soyisim,tarih) values ('MEHMET','GÜNEŞ',CURRENT_TIMESTAMP)";

    // $sql = "delete from kisiler where isim like 'ME%'";

    // if(mysqli_query($baglanti,$sql)){
    //     echo "ekleme başarılı";
    // }
    // else
    // {
    //     echo "HATA";
    // }

    echo "<br>";
    
    $sql = "select * from kisiler";
    $sonuc = mysqli_query($baglanti,$sql);

    while ($sutun = mysqli_fetch_assoc($sonuc)) {
        echo $sutun["id"] ." ". $sutun["isim"] ." ". $sutun["soyisim"] ." ". $sutun["tarih"] . "<br>";
    }

    mysqli_close($baglanti);
    ?>
</body>
</html>