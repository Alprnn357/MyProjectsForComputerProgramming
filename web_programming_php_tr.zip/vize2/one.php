<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>heheeee</title>
</head>
<body>
    <?php
    echo $_SESSION['text1'];
    echo "<br>";
    echo $_SESSION['text2'];
    echo "<br>";
    echo "<br>";
    
    if(isset($_COOKIE[$c_name]))
        echo "Yes u did it. it is: " . $_COOKIE[$c_name];
    else
        echo "WTF DID YOU DO BRO!";
    ?>
</body>
</html>