<?php
session_start();

if ( isset($_SESSION["email"]) && isset($_SESSION["password"]) ) {
    header('Location: mainpage.php');
}
else
{
    session_unset();
    session_destroy();
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Giriş Yap</title>
</head>
<body>
    <!-- soru:
user tablosu olcak
id, eposta, şifre istiyorum
giriş zamanı session time sütunu olsun
3 tane sayfa
1 tanesi kullanıcı giriş sayfası
1 tanesi kullanıcı kayıt sayfası
1 tane ana sayfa web sitemize hoş geldinix eposta unique -->

    <?php
    include "class/vt.php";
    ?>

    <h1>Giriş yapınız</h1>

    <form method="post" enctype="multipart/form-data">
        <label for="email">E-posta: </label><input type="text" name="email"><br>
        <label for="password">Şifre: </label><input type="password" name="password"><br>
        <input type="submit" formaction="logined.php" value="Giriş">
        <input type="submit" formaction="register.php" value="Kaydol">
    </form>


</body>
</html>