<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="style.css">
    <meta charset="UTF-8" />
    <title>Form</title>
</head>

<body>
    <?php
    include "class/vt.php";

    // $servername = "127.0.0.1";
    // $username = "root";
    // $password = "";
    // $dbname = "bozok";

    $sql1 = "SELECT * FROM students";

    $result1 = $baglanti->conn->query($sql1);

    ?>

    <h1>Öğrenci Kayıt Sistemi Girişi</h1>
    <br>

    <div class="cerceve">
        <b style="font-size: 25px;">Girilecek kayıt:</b><br><br>
            <form method="post" enctype="multipart/form-data">
                <label>ID: </label> <input type="text" name="id"><br>
                <label>Adı: </label> <input type="text" name="firstName"><br>
                <label>Soyadı: </label> <input type="text" name="lastName"><br>
                <label>Okul no: </label> <input type="text" name="schoolno"><br>
                <label>Şehir: </label> <input type="text" name="city"><br><br>
                <input type="submit" class="dugme" formaction="ekleme.php" value="Kayıt ekle">
                <input type="submit" class="dugme" formaction="silme.php" value="Kayıt sil">
                <input type="submit" class="dugme" formaction="guncelleme.php" value="Kayıt güncelle">
                <input type="reset" class="dugme" value="Temizle">
            </form>
    </div>
    <br>

    <?php
    include "tablo.php";
    ?>

</body>

</html>