<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Çıkış sayfası</title>
</head>
<body>

    <?php
    session_unset();
    session_destroy();
    ?>

    <h1>Çıkış yapıldı!</h1><br>
    <a href="index.php">tamam</a>

</body>
</html>