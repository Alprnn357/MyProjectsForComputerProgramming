<!DOCTYPE html>
<html>
    <body>

    <?php
    $cars = array("Volvo", "BMW", "Toyota"); 
    echo "I like " . $cars[0] . ", " . $cars[1] . " and " . $cars[2] . ".";

    $x = 0
    for($x = 0; $x < 3; $x++) {
        echo $cars[$x];
    };
    ?>

    </body>
</html>
