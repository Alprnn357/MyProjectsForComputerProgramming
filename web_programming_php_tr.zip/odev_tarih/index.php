<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zaman</title>
</head>
<body>
    <p>Zaman damgası türkçe</p><br>
    <?php

    

    function day_tr(int $a) {
        if ($a == 0) {
            if (date("D") == "Mon")
                return 'Pzt';
            elseif (date("D") == "Tue")
                return 'Sal';
            elseif (date("D") == "Wed")
                return 'Çar';
            elseif (date("D") == "Thu")
                return 'Per';
            elseif (date("D") == "Fri")
                return 'Cum';
            elseif (date("D") == "Sat")
                return 'Cmt';
            elseif (date("D") == "Sun")
                return 'Pzr';
        }
        elseif ($a == 1) {
            if (date("D") == "Mon")
                return 'Pazartesi';
            elseif (date("D") == "Tue")
                return 'Salı';
            elseif (date("D") == "Wed")
                return 'Çarşamba';
            elseif (date("D") == "Thu")
                return 'Perşembe';
            elseif (date("D") == "Fri")
                return 'Cuma';
            elseif (date("D") == "Sat")
                return 'Cumartesi';
            elseif (date("D") == "Sun")
                return 'Pazar';
        }
        else
            return null;

    }

    function month_tr(int $a) {
        if ($a == 0) {
            if (date("M") == "Jan")
                return 'Oca';
            elseif (date("M") == "Feb")
                return 'Şub';
            elseif (date("M") == "Mar")
                return 'Mar';
            elseif (date("M") == "Apr")
                return 'Nis';
            elseif (date("M") == "May")
                return 'May';
            elseif (date("M") == "Jun")
                return 'Haz';
            elseif (date("M") == "Jul")
                return 'Tem';
            elseif (date("M") == "Aug")
                return 'Ağu';
            elseif (date("M") == "Sep")
                return 'Eyl';
            elseif (date("M") == "Oct")
                return 'Eki';
            elseif (date("M") == "Nov")
                return 'Kas';
            elseif (date("M") == "Dec")
                return 'Ara';
        }
        elseif ($a == 1) {
            if (date("M") == "Jan")
                return 'Ocak';
            elseif (date("M") == "Feb")
                return 'Şubat';
            elseif (date("M") == "Mar")
                return 'Mart';
            elseif (date("M") == "Apr")
                return 'Nisan';
            elseif (date("M") == "May")
                return 'Mayıs';
            elseif (date("M") == "Jun")
                return 'Haziran';
            elseif (date("M") == "Jul")
                return 'Temmuz';
            elseif (date("M") == "Aug")
                return 'Ağustos';
            elseif (date("M") == "Sep")
                return 'Eylül';
            elseif (date("M") == "Oct")
                return 'Ekim';
            elseif (date("M") == "Nov")
                return 'Kasım';
            elseif (date("M") == "Dec")
                return 'Aralık';
        }
        else
            return null;
        
        
    }

    function date_tr($x) {
        if ($x >= 0 && $x <= 1)
            return $sonuc = date("d") . " " . month_tr($x) . " " . date("Y") . " " . day_tr($x);
        else
            return null;
        
    }

    echo "Bugünün tarihi: " . date("d") . " " . month_tr(1) . " " . date("Y") . " " . day_tr(1) . "<br>";
    echo "Bugünün tarihi: " . date_tr(0) . "<br>";
    
    ?>
</body>
</html>