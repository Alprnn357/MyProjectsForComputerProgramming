<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Gönderildi</title>
</head>
<body>
    <h1>Başarılı!</h1>
</body>
</html>