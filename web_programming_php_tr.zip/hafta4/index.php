<!DOCTYPE html>
<html>
    <body>

        <?php
        $maas = 11000;
        $yil = 8;
        $ay = 7;

        $ay = $ay + ($yil * 12); //103 ay

        function zamm($ay,$maas) {
            $x = 0;
            for($i = 1; $i <= $ay; $i++){
                if($i % 6 == 0){
                    $x = $x + (($maas * 23) / 100);
                }
            }

            return $x;
        }

        function ikramiye($yil,$maas) {
            $y = 0;
            for($i = 1; $i <= $yil; $i++){
                if($i % 6 == 0){
                    $y = $y + (($maas * 3) / 4);
                }
            }

            return $y;
        }

        echo "Bir işçinin toplam aldığı maaş:"."<br>";
        $sonuc = $maas + zamm($ay,$maas) + ikramiye($yil,$maas);
        echo number_format($sonuc,2,",",".") . " TL";

        ?>
        <!-- bir işçi maaşı belirle, int her 6 ayda bir maaşa %23 zam, her yıl aldığı maaşın 4 te 3 ü kadar ikramiye kazanıyor. 11 bin maaş alan işçi 8 yıl 7 ay sonra ne kadar kazanç sağlamıştır -->
    </body>
</html>
