<?php
session_start();

$c_name = "anaa1";
$c_value = "Alper Keskin";
setcookie($c_name,$c_value, time() + (86400 * 30) , "/"); // 86400 = 1 day
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>vize2</title>
</head>
<body>
    <h1>Merhabaaaaaaa</h1><br>
    <?php
    $yazi = 'zort';

    function benim1(&$x) {
        $x = 'Benim adım Alperen nasılsın iyi misin?';
    }

    echo benim1($yazi);
    echo "<br>";
    echo $yazi;
    echo "<br>";
    echo "<br>";
    echo "<br>";
    
    $_SESSION['text1'] = 'Merhaba kdaskdjjaskjdkjaskjdkjaksdjkja';
    $_SESSION['text2'] = 'Atla patla zıpla yapma';
    $_SESSION['zart'] = array('yes'=>'no');

    echo $_SESSION['text1'];
    echo "<br>";
    echo $_SESSION['text2'];
    echo "<br>";
    echo $_SESSION['zart']['yes'];
    echo "<br>";
    echo "<br>";
    
    if(isset($_COOKIE[$c_name]))
        echo "Yes u did it. " . $c_name . " is: " . $_COOKIE[$c_name];
    else
        echo "WTF DID YOU DO BRO!";


    ?>
</body>
</html>