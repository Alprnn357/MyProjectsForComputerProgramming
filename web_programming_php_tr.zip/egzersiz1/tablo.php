    <table>
        <tr>
            <td>
                <b>ID</b>
            </td>
            <td>
                <b>Adı</b>
            </td>
            <td>
                <b>Soyadı</b>
            </td>
            <td>
                <b>Okul no</b>
            </td>
            <td>
                <b>Şehir</b>
            </td>
        </tr>
    <?php
    if ($result1->num_rows > 0) {
        while ($row = $result1->fetch_assoc()) {
            echo "<tr>";

            echo "<td>" . $row["id"] . "</td><td>" . $row["firstName"] . "</td><td>" . $row["lastName"] . "</td><td>" . $row["schoolno"] . "</td><td>" . $row["city"] . "</td>";

            echo "</tr>";

            //echo $row["id"] . " " . $row["firstName"] . " " . $row["lastName"] . " " . $row["schoolno"] . " " . $row["city"] . "<br>";
        }
    }

    $baglanti->conn->close();
    ?>
    </table>
